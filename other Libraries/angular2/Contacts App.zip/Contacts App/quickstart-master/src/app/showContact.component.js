"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var contact_service_1 = require("./contact.service");
var showContact = (function () {
    function showContact(_route, _contactService) {
        this._route = _route;
        this._contactService = _contactService;
        this.contactList = [];
        this.AllContacts = [
            {
                "firstName": "Joe",
                "lastName": "Perry",
                "contactNumber": "444-888-1223",
                "contactEmail": "joe@cordis.us"
            },
            {
                "firstName": "Kate",
                "lastName": "Will",
                "contactNumber": "244-838-1213",
                "contactEmail": "kate@cordis.us"
            },
            {
                "firstName": "Harry",
                "lastName": "Robert",
                "contactNumber": "744-138-1292",
                "contactEmail": "harry@cordis.us"
            },
            {
                "firstName": "Tom",
                "lastName": "Bill",
                "contactNumber": "241-188-1191",
                "contactEmail": "tom@cordis.us"
            },
            {
                "firstName": "Roger",
                "lastName": "Steel",
                "contactNumber": "111-177-1231",
                "contactEmail": "roger@cordis.us"
            }
        ];
    }
    showContact.prototype.onSelect = function (contact) {
        this._route.navigate(['/showContact', contact.firstName]);
    };
    showContact.prototype.ngOnInit = function () {
        /*this._contactService.getContacts()
        .subscribe((respData:Response)=>this.contactList=respData);*/
        this.contactList = this.AllContacts;
    };
    showContact.prototype. = function* () { };
    return showContact;
}());
showContact = __decorate([
    core_1.Component({
        selector: 'show-contact',
        template: "\n<ul class=\"items\">\n<li (click)=\"onSelect(contact)\" *ngFor=\"let contact of contactList\">\n<span class=\"badge\">{{contact.firstName}}\n{{contact.lastName}}</span></li>\n</ul>\n"
    }),
    __metadata("design:paramtypes", [router_1.Router, contact_service_1.contactService])
], showContact);
exports.showContact = showContact;
/;
//# sourceMappingURL=showContact.component.js.map