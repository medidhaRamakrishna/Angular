# Angular2 Contact App

Steps to Start the application
1)Install Node Js and run  
# npm install
to install all the dependencies 
# npm start
to start the Angular2 Application
