"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var shopingList = (function () {
    function shopingList() {
        this.toggle = true;
        this.Items_List = [{ name: 'Milk' },
            { name: 'Bread' },
            { name: 'Sugar' },
            { name: 'Rice' }];
        this.selectedItem = { name: "" };
    }
    shopingList.prototype.editItem = function (item) {
        this.selectedItem = item;
        this.toggle = !this.toggle;
    };
    shopingList.prototype.toggleShow = function () {
        this.toggle = !this.toggle;
    };
    shopingList.prototype.addItem = function (itemRef) {
        this.duplicateVal = this.Items_List.filter(function (obj) {
            return obj.name == itemRef.value;
        });
        if (itemRef.value != '' && this.duplicateVal.length == 0) {
            this.Items_List.push({ name: itemRef.value });
        }
        else {
            if (itemRef.value != '')
                alert('Items already Added');
        }
        itemRef.value = '';
    };
    shopingList.prototype.deleteItem = function (item) {
        this.Items_List.splice(this.Items_List.indexOf(item), 1);
    };
    return shopingList;
}());
shopingList = __decorate([
    core_1.Component({
        selector: 'shopping-list',
        templateUrl: './Groceries_Template.html'
    })
], shopingList);
exports.shopingList = shopingList;
//# sourceMappingURL=shoping-list.component.js.map