# Angular2 Application to Perform CRUD Operations
The following operations possible using this application,
1)Add new Items to the List
2)Editing the Existing Items
3)Delete the Existing Items.

# Starting Application
install nodejs and 
run the below command to install all the dependencies
# npm install
to start the angular2 Application run below command
# npm start
